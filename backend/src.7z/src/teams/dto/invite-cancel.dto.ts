export class InviteCancelDto {
    inviterId: number;
    inviteeId: number;
    teamId: number;
}