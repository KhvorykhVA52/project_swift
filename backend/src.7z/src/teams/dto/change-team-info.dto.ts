export class ChangeTeamInfoDto {
    teamId: number;
    name: string;
    description: string
}