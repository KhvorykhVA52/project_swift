export class ChangeTeamleaderDto {
    memberId: number;
    teamId: number
}