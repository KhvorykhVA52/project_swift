export class MemberRemoveDto {
    memberId: number;
    teamId: number
}