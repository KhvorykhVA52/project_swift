export class CreateIdeaDto {
    name:string;
    problem:string;
    solution:string;
    result:string;
    resource:string;
    initiatorId: number;
}