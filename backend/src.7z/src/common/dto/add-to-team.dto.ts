export class AddToTeamDto {
  teamId: number;
  userId: number;
}