export type CreateTeamDto = {
    name: string;
    description: string;
  }