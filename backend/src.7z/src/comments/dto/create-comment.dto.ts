export class CreateCommentDto {
    comment: string;
    grade: string;
    author: number;
    idea: number;
  }
  