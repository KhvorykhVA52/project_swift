export class UpdateCommentDto {
    comment?: string;
    grade?: string;
  }
  